# -*- coding: utf-8 -*-

from odoo import models, fields, api



class ConsolidationChartReplica(models.Model):
    _name = "cai.consolidation.chart"
    _description = "subsidiary Consolidation Journal"
    _inherit = ['consolidation.chart']
    
    children_ids = fields.Many2many('cai.consolidation.chart', 'cai_report_inner_rel', 'children_ids',
                                    'parent_ids', string="Sub-consolidations")
    parents_ids = fields.Many2many('cai.consolidation.chart', 'cai_report_inner_rel', 'parent_ids',
                                   'children_ids', string="Consolidated In")
    

class ConsolidationAccountReplica(models.Model):
    _name = "cai.consolidation.account"
    _description = "Subsidiary Consolidation account"
    _inherit = ['consolidation.account']
    
    using_ids = fields.Many2many('cai.consolidation.account', 'rel', 'used_in_ids',
                                 'using_ids', string="Consolidation Accounts")
    used_in_ids = fields.Many2many('cai.consolidation.account', 'rel', 'using_ids',
                                   'used_in_ids', string='Consolidated in')
    

    
class ConsolidationGroupReplica(models.Model):
    _name = "cai.consolidation.group"
    _description = "Subsidiary Consolidation Group"
    _inherit = ['consolidation.group']