# -*- coding: utf-8 -*-

from odoo import models, fields, api



class ConsolidationJournalReplica(models.Model):
    _name = "cai.consolidation.journal"
    _description = "subsidiary Consolidation Journal"
    _inherit = ['consolidation.journal']


class ConsolidationJournalLineReplical(models.Model):
    _name = "cai.consolidation.journal.line"
    _description = "subsidiaryConsolidation journal line"
    _inherit = ['consolidation.journal.line']
