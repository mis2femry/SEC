# -*- coding: utf-8 -*-

from . import cai_account_account
from . import cai_account_move
from . import cai_consolidation_coa
from . import cai_consolidation_period
from . import cai_consolidation_journal
from . import cai_consolidation_rate
from . import res_company
