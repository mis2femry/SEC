# -*- coding: utf-8 -*-

from odoo import models, fields, api



class ConsolidationRateReplica(models.Model):
    _name = "cai.consolidation.rate"
    _description = "subsidiary Consolidation Rate"
    _inherit = ['consolidation.rate']
