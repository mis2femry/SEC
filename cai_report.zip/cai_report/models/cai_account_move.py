# -*- coding: utf-8 -*-

from odoo import models, fields


class AccountMoveLineReplica(models.Model):
    _inherit = 'account.move.line'

    cai_consolidation_journal_line_ids = fields.Many2many('cai.consolidation.journal.line', string="Cai Consolidation Journal Line")
