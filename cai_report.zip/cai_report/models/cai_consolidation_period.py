# -*- coding: utf-8 -*-

from odoo import models, fields, api



class ConsolidationPeriodReplica(models.Model):
    _name = "cai.consolidation.period"
    _description = "subsidiary Consolidation Period"
    _inherit = ['consolidation.period']
    
    chart_id = fields.Many2one('cai.consolidation.chart', string="Consolidation", required=True, ondelete='cascade')
    using_composition_ids = fields.One2many('cai.consolidation.period.composition','using_period_id')
    used_in_composition_ids = fields.One2many('cai.consolidation.period.composition','composed_period_id')

    company_period_ids = fields.One2many('cai.consolidation.company_period', 'period_id', string="Company Periods", copy=False)
    journal_ids = fields.One2many('cai.consolidation.journal', 'period_id', string="Journals")
    
    

class ConsolidationPeriodCompositionReplica(models.Model):
    _name = "cai.consolidation.period.composition"
    _description = "subsidiary Consolidation Period Composition"
    _inherit = ['consolidation.period.composition']
    
    composed_period_id = fields.Many2one('cai.consolidation.period', ondelete="cascade", string="Composed Analysis Period", required=True)
    using_period_id = fields.Many2one('cai.consolidation.period', string="Analysis Period Using This", ondelete="cascade", required=True)
    
    

class ConsolidationCompanyPeriodReplica(models.Model):
    _name = "cai.consolidation.company_period"
    _description = "subsidiary Consolidation Company Period"
    _inherit = ['consolidation.company_period']
    
    chart_id = fields.Many2one('cai.consolidation.chart', related="period_id.chart_id", string="Chart")
    period_id = fields.Many2one('cai.consolidation.period', string="Period", required=True, ondelete="cascade")
    
    
   